int main()
{
	int n = 0;

	n = 3;
	3 = n;

	int& r1 = n;
	int& r2 = 3;

	int&& r3 = n;
	int&& r4 = 3;
}
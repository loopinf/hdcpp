// 64 page ~
int main()
{
	int n = 0;

	const int c1 = n;
	const int c2 = 3;

//	constexpr int c3 = n;
	constexpr int c4 = 3;

	int k1 = c1;
	int k2 = c4;
}